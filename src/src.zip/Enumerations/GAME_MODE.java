package Enumerations;

/**
 *
 * @author Jeezy
 */
public enum GAME_MODE {
  INTRO,
  START_MENU,
  RUNNING,
  PAUSED,
  GAME_OVER
}