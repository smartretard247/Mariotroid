package Main;

/**
 *
 * @author Jeezy
 */
public class GameOverException extends Exception {

  public GameOverException() {
    super("GAME OVER");
  }
  
}
